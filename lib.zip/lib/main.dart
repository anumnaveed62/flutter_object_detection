import 'dart:async';
import 'dart:convert';
import 'dart:html' as html;
import 'dart:js_util' as js_util;
import 'dart:typed_data';
import 'dart:ui_web' as ui_web;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Web Object Detection',
      theme: ThemeData(primarySwatch: Colors.indigo, useMaterial3: true),
      home: const ObjectDetectionPage(),
    );
  }
}

class ObjectDetectionPage extends StatefulWidget {
  const ObjectDetectionPage({super.key});

  @override
  State<ObjectDetectionPage> createState() => _ObjectDetectionPageState();
}

class _ObjectDetectionPageState extends State<ObjectDetectionPage> {
  static const String _imgElementId = 'detect-img';
  static const String _viewType = 'detect-img-view';

  List<dynamic> _predictions = [];
  String? _imageUrl;
  bool _loading = false;
  bool _viewRegistered = false;
  double _imgNaturalWidth = 0;
  double _imgNaturalHeight = 0;

  html.ImageElement? _imageElement;

  @override
  void initState() {
    super.initState();
    _registerImageView();
  }

  void _registerImageView() {
    if (_viewRegistered) return;
    _imageElement = html.ImageElement()
      ..id = _imgElementId
      ..style.width = '100%'
      ..style.height = '100%'
      ..style.objectFit = 'contain';

    ui_web.platformViewRegistry.registerViewFactory(
      _viewType,
      (int viewId) => _imageElement!,
    );
    _viewRegistered = true;
  }

  Future<void> _pickAndDetect() async {
    final picker = ImagePicker();
    final XFile? file = await picker.pickImage(source: ImageSource.gallery);
    if (file == null) return;

    final Uint8List bytes = await file.readAsBytes();
    final blob = html.Blob([bytes]);
    final url = html.Url.createObjectUrlFromBlob(blob);

    setState(() {
      _imageUrl = url;
      _predictions = [];
      _loading = true;
    });

    final completer = Completer<void>();
    _imageElement!.onLoad.first.then((_) {
      _imgNaturalWidth = _imageElement!.naturalWidth.toDouble();
      _imgNaturalHeight = _imageElement!.naturalHeight.toDouble();
      completer.complete();
    });
    _imageElement!.src = url;
    await completer.future;

    try {
      final result = await js_util.promiseToFuture<String>(
        js_util.callMethod(html.window, 'detectObjects', [_imgElementId]),
      );
      setState(() {
        _predictions = jsonDecode(result) as List<dynamic>;
      });
    } catch (e) {
      debugPrint('Detection error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Detection failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Flutter Web Object Detection')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton.icon(
              onPressed: _loading ? null : _pickAndDetect,
              icon: const Icon(Icons.image_search),
              label: const Text('Pick Image & Detect Objects'),
            ),
            const SizedBox(height: 16),
            if (_imageUrl != null)
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    return Stack(
                      children: [
                        Positioned.fill(
                          child: HtmlElementView(viewType: _viewType),
                        ),
                        if (_predictions.isNotEmpty &&
                            _imgNaturalWidth > 0 &&
                            _imgNaturalHeight > 0)
                          ..._buildBoundingBoxes(constraints),
                      ],
                    );
                  },
                ),
              ),
            if (_loading) const Padding(
              padding: EdgeInsets.all(12.0),
              child: CircularProgressIndicator(),
            ),
            if (_predictions.isNotEmpty)
              SizedBox(
                height: 140,
                child: ListView(
                  children: _predictions.map((p) {
                    final score = (p['score'] as num) * 100;
                    return ListTile(
                      dense: true,
                      leading: const Icon(Icons.label_outline),
                      title: Text(p['class'].toString()),
                      trailing: Text('${score.toStringAsFixed(1)}%'),
                    );
                  }).toList(),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // Draws bounding boxes over the displayed image using the object-fit:
  // contain scaling math, mapping natural image pixels -> widget pixels.
  List<Widget> _buildBoundingBoxes(BoxConstraints constraints) {
    final double boxW = constraints.maxWidth;
    final double boxH = constraints.maxHeight;

    final double scale = (boxW / _imgNaturalWidth < boxH / _imgNaturalHeight)
        ? boxW / _imgNaturalWidth
        : boxH / _imgNaturalHeight;

    final double renderedW = _imgNaturalWidth * scale;
    final double renderedH = _imgNaturalHeight * scale;
    final double offsetX = (boxW - renderedW) / 2;
    final double offsetY = (boxH - renderedH) / 2;

    return _predictions.map<Widget>((p) {
      final bbox = (p['bbox'] as List).map((e) => (e as num).toDouble()).toList();
      final double x = offsetX + bbox[0] * scale;
      final double y = offsetY + bbox[1] * scale;
      final double w = bbox[2] * scale;
      final double h = bbox[3] * scale;

      return Positioned(
        left: x,
        top: y,
        width: w,
        height: h,
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.redAccent, width: 2),
          ),
          child: Align(
            alignment: Alignment.topLeft,
            child: Container(
              color: Colors.redAccent,
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              child: Text(
                '${p['class']} ${((p['score'] as num) * 100).toStringAsFixed(0)}%',
                style: const TextStyle(color: Colors.white, fontSize: 11),
              ),
            ),
          ),
        ),
      );
    }).toList();
  }
}
